// /app/page.tsx
"use client";

import React from "react";
import FinancePage from "./finance/page";

export default function Home() {
  return <FinancePage />;
}
